//! Block-scoped activation checkpointing with a single recomputation step.

use crate::{
    checkpoint::{base::Checkpointer, builder::CheckpointerBuilder},
    grads::Gradients,
    graph::{NodeId, NodeRef, Parent, Requirement, Step},
    tensor::AutodiffTensor,
    Autodiff,
    checkpoint::strategy::NoCheckpointing,
};
use alloc::{boxed::Box, vec::Vec};
use burn_tensor::{backend::Backend, Tensor, TensorPrimitive};
use core::fmt;

/// A local gradient and the outer graph node to which it must be returned.
pub struct GradBridge<B: Backend> {
    /// Node in the outer graph.
    pub outer_node_id: NodeId,
    /// Leaf in the isolated local graph.
    pub local_tensor: AutodiffTensor<B>,
}

/// One graph step representing an entire model block.
pub struct CheckpointBlockStep<B: Backend, const OUT_RANK: usize> {
    output_node: NodeRef,
    parents: Vec<Parent>,
    recompute_fn: Box<
        dyn FnOnce(
                ) -> (Tensor<Autodiff<B, NoCheckpointing>, OUT_RANK>, Vec<GradBridge<B>>)
            + Send,
    >,
}

impl<B: Backend, const OUT_RANK: usize> fmt::Debug for CheckpointBlockStep<B, OUT_RANK> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CheckpointBlockStep")
            .field("output_node", &self.output_node.id)
            .field("parents", &self.parents.len())
            .field("out_rank", &OUT_RANK)
            .finish()
    }
}

impl<B: Backend, const OUT_RANK: usize> Step for CheckpointBlockStep<B, OUT_RANK> {
    fn step(self: Box<Self>, grads: &mut Gradients, _checkpointer: &mut Checkpointer) {
        let output_gradient = grads.consume::<B>(&self.output_node);
        let (local_output, bridges) = (self.recompute_fn)();
        let local_gradient = Tensor::<Autodiff<B, NoCheckpointing>, OUT_RANK>::from_primitive(
            TensorPrimitive::Float(AutodiffTensor::new(output_gradient)),
        );
        let output_flat = local_output.flatten::<1>(0, OUT_RANK - 1);
        let gradient_flat = local_gradient.flatten::<1>(0, OUT_RANK - 1);
        let mut local_grads = (output_flat * gradient_flat).sum().backward();

        for bridge in bridges {
            if let Some(gradient) = local_grads.remove(&bridge.local_tensor) {
                grads.register::<B>(bridge.outer_node_id, gradient);
            }
        }
    }

    fn node(&self) -> NodeId {
        self.output_node.id
    }

    fn parents(&self) -> &[Parent] {
        &self.parents
    }

    fn depth(&self) -> usize {
        self.output_node.order
    }
}

/// Register one recomputation step for an output with dynamically many parents.
pub fn register_dynamic_checkpoint<B: Backend, const OUT_RANK: usize>(
    output: B::FloatTensorPrimitive,
    parent_nodes: &[NodeRef],
    recompute_fn: Box<
        dyn FnOnce(
                ) -> (Tensor<Autodiff<B, NoCheckpointing>, OUT_RANK>, Vec<GradBridge<B>>)
            + Send,
    >,
) -> AutodiffTensor<B> {
    let parents = parent_nodes
        .iter()
        .filter_map(|node| node.clone_if_require_grad())
        .collect::<Vec<_>>();
    if parents.is_empty() {
        return AutodiffTensor::new(output);
    }

    let result = AutodiffTensor::from_parents(
        output,
        &parents,
        Requirement::Grad,
        crate::graph::ComputingProperty::ComputeBound,
    );
    let step = CheckpointBlockStep {
        output_node: result.node.clone(),
        parents: result.node.parents.clone(),
        recompute_fn,
    };
    result.register_step(step, CheckpointerBuilder::default())
}
